package cfg;

public class EndBlock extends Block {

    public EndBlock(String name, String function) {
        super(name + "EndBlock", function);
    }
}
