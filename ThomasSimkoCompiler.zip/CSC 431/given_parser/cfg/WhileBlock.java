package cfg;

public class WhileBlock extends Block {
    public WhileBlock(String label, String function) {
        super(label, function);
    }
}
