package arm.ArmValue.FinalRegisters;

public abstract class NotInterferingRegister extends ArmFinalRegister {

    public NotInterferingRegister(String register) {
        super(register);
    }
}
