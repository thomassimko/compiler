package arm.ArmValue;

public interface ArmValue {
    String toArm();
}
