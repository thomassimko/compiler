package arm;

public enum MoveType {
    W, T, EQ, LT, GT, NE, LE, GE, DEFAULT
}
