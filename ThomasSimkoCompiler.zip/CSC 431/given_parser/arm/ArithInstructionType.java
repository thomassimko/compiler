package arm;

public enum ArithInstructionType {
    ADD, SUB, MUL, AND, OR, XOR
}
