package arm;

public
enum BranchType {
    EQ, LT, GT, NE, LE, GE, DEFAULT, L
}
