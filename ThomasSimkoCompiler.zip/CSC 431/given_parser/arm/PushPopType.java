package arm;

public enum PushPopType {
    PUSH, POP
}
