package ast;

public interface Type
{
    String getCFGType();
}
