package llvm.lattice;

public class LatticeTop implements LatticeValue {
}
