package llvm.lattice;

public enum LatticeTypes {
    TOP, CONST, BOTTOM
}
