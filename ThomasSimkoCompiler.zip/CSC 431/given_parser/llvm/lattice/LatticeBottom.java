package llvm.lattice;

public class LatticeBottom implements LatticeValue {
}
