package llvm.lattice;

public interface LatticeValue {
}
