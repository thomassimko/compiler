To compile files please run the script compile.sh.
This script takes one parameter: the .mini file you wish to compile.

If you wish to run the file completely, use the script run.sh with the same argument.
This script will compile the file and run it with gcc.

Notes:
    - These scripts compile the file will all optimizations.
    - The output is saved into output.s and output.out
